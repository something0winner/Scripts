from __future__ import annotations
import uuid
from abc import ABC
from urllib.parse import parse_qs
from contextlib import suppress
from random import choice
from email.utils import formatdate
from twisted.web.resource import Resource

from honeypots.base_server import BaseServer
from honeypots.helper import load_template, get_headers_and_ip_from_request, check_bytes

class BaseHttpServer(BaseServer, ABC):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.mocking_server = "Microsoft-IIS/10.0"

    class MainResource(Resource):
        isLeaf = True  # noqa: N815
        home_file = load_template("home.html")
        login_file = load_template("login.html")

        def __init__(self, *args, hp_server: BaseHttpServer = None, **kwargs):
            super().__init__(*args, **kwargs)
            self.hp_server = hp_server
            self.headers = {}

        def render(self, request):
            client_ip, headers = get_headers_and_ip_from_request(request, self.hp_server.options)
            request.responseHeaders.removeHeader("Date")
            request.responseHeaders.removeHeader("Content-Type")
            request.responseHeaders.removeHeader("Server")
            request_id = str(uuid.uuid4())
            request.responseHeaders.addRawHeader("Cache-Control", "no-cache, no-store")
            request.responseHeaders.addRawHeader("Pragma", "no-cache")
            request.responseHeaders.addRawHeader("Content-Type", "text/html; charset=utf-8")
            request.responseHeaders.addRawHeader("Expires", "-1")
            request.responseHeaders.addRawHeader("Server", "Microsoft-IIS/10.0")
            request.responseHeaders.addRawHeader("Request-Id", request_id)
            request.responseHeaders.addRawHeader("X-Frame-Options", "SAMEORIGIN")
            request.responseHeaders.addRawHeader("X-AspNet-Version","4.0.30319")
            request.responseHeaders.addRawHeader("X-Powered-By", "ASP.NET")
            request.responseHeaders.addRawHeader("Date", formatdate(timeval=None, localtime=False, usegmt=True))
            with suppress(Exception):
                log_data = {
                    "action": "connection",
                    "src_ip": client_ip,
                    "src_port": request.getClientAddress().port,
                }
                if "capture_commands" in self.hp_server.options:
                    log_data["data"] = headers
                self.hp_server.log(log_data)


            if request.method in (b"GET", b"POST"):
                self.hp_server.log(
                    {
                        "action": request.method.decode(),
                        "src_ip": client_ip,
                        "src_port": request.getClientAddress().port,
                    }
                )

            if request.method == b"GET":
                if (
                    request.uri == b"/owa/auth.owa"
                    and self.hp_server.username != ""
                    and self.hp_server.password != ""
                ):
                    return self.login_file

                return self.login_file

            if request.method == b"POST":
                self.headers = request.getAllHeaders()
                if (
                    request.uri in (b"/owa/auth.owa", b"/")
                    and self.hp_server.username != ""
                    and self.hp_server.password != ""
                ):
                    form = parse_qs(request.content.read(int(self.headers.get(b"content-length"))))
                    if b"username" in form and b"password" in form:
                        username = check_bytes(form[b"username"][0])
                        password = check_bytes(form[b"password"][0])
                        self.hp_server.check_login(
                            username, password, client_ip, request.getClientAddress().port
                        )

            return self.home_file
